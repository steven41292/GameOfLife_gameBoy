//Steven Wojcio
//A3
//Brandon Whitehead

#include "game2Lib.h"


int main(){
	REG_DISPCTL=MODE4|BG2_ENABLE;
	
	gameLogic();	
	return 0;
}
