/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode4 nextModeButton NextMode.png 
 * 
 * Image Information
 * -----------------
 * NextMode.png 50@12
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * Resolve is never stronger than in the morning after the night it was never weaker.  ~From the movie Naked
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef NEXTMODEBUTTON_BITMAP_H
#define NEXTMODEBUTTON_BITMAP_H

extern const unsigned short nextModeButton[300];
extern const unsigned short nextModeButton_palette[2];
#define NEXTMODEBUTTON_WIDTH 50
#define NEXTMODEBUTTON_HEIGHT 12
#define NEXTMODEBUTTON_PALETTE_SIZE 2

#endif