/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode4 2 2.png 
 * 
 * Image Information
 * -----------------
 * 2.png 20@12
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * Resolve is never stronger than in the morning after the night it was never weaker.  ~From the movie Naked
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef Two_BITMAP_H
#define Two_BITMAP_H

extern const unsigned short Two[120];
extern const unsigned short Two_palette[2];
#define Two_WIDTH 20
#define Two_HEIGHT 12
#define Two_PALETTE_SIZE 2

#endif
